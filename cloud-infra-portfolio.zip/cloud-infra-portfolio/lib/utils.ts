import { clsx, type ClassValue } from "clsx";

/**
 * Merges class names conditionally. Kept dependency-light (no tailwind-merge)
 * since this project intentionally avoids conflicting utility combinations.
 */
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}
