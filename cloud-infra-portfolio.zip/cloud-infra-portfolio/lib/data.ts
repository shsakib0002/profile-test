// ─────────────────────────────────────────────────────────────────────────
// SITE CONTENT — populated from Md. Sakib Hasan's actual CV.
// A few things are still placeholders (marked with TODO) since they weren't
// on the CV — fill these in and everything on the page updates automatically.
// ─────────────────────────────────────────────────────────────────────────

export const siteConfig = {
  name: "Md. Sakib Hasan",
  initials: "SH",
  role: "Infrastructure & Network Operations Engineer",
  company: "Huawei Technologies Bangladesh",
  location: "Dhaka, Bangladesh",
  email: "[email protected]",
  phone: "+880 1760-142822",
  availability: "Open to new opportunities",
  tagline: "Keeping enterprise telecom infrastructure available, stable, and secure.",
  description:
    "Infrastructure & Network Operations Engineer at Huawei Technologies Bangladesh, supporting Huawei 5G Core platforms and building toward a career in cloud engineering.",
  url: "https://yourdomain.com", // TODO: point this at your deployed domain
  github: "https://github.com/yourusername", // TODO: add your GitHub — not listed on the CV
  githubUsername: "yourusername", // TODO: same as above
  linkedin: "https://www.linkedin.com/in/md-sakib-hasan-infosec",
  resumeUrl: "/resume.pdf",
  keywords: [
    "Network Operations Center Engineer",
    "Infrastructure Engineer",
    "Huawei 5G Core",
    "AWS Cloud Practitioner",
    "RHCSA",
    "Linux Administration",
    "Enterprise Networking",
    "Telecom Infrastructure",
    "Dhaka",
    "Bangladesh",
  ],
};

export const navLinks = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#skills", label: "Skills" },
  { href: "#certifications", label: "Certifications" },
  { href: "#projects", label: "Projects" },
  { href: "#contact", label: "Contact" },
];

export const heroBadges = ["AWS Cloud", "Huawei FusionCloud", "Linux (RHCSA)", "Docker", "5G Core Networks"];

export const stats = [
  { label: "Years of Experience", value: 1, suffix: "+" },
  { label: "Certifications Earned", value: 3, suffix: "+" },
  { label: "Core Network Platforms Supported", value: 4, suffix: "" },
  { label: "Operations Coverage", value: 24, suffix: "×7" },
];

export const about = {
  paragraphs: [
    "I'm an Infrastructure & Network Operations Engineer at Huawei Technologies Bangladesh, where I monitor and support Huawei 5G Core platforms — including UDM, AAA, ENUM, and iMaster MAE — to keep telecom services available and stable around the clock.",
    "My background spans Linux administration (RHCSA), virtualization, and privileged access management, with a growing foundation in AWS and Huawei FusionCloud. I'm currently pursuing an MSc in IT System Security while working toward a long-term move into cloud engineering.",
  ],
  highlights: [
    { title: "Monitor & respond", description: "Track Huawei 5G Core platform health and resolve incidents in a live 24×7 telecom environment." },
    { title: "Operate infrastructure", description: "Hands-on with Linux administration, virtualization, and enterprise network fundamentals." },
    { title: "Learn & certify", description: "Continuously building cloud expertise through AWS, Huawei, and Red Hat certification tracks." },
    { title: "Document & report", description: "Maintain KPI summaries, incident reports, and shift handover documentation to enterprise standards." },
  ],
};

export const experience = [
  {
    company: "Huawei Technologies Bangladesh",
    role: "Network Operations Center Engineer (L1)",
    period: "Feb 2026 — Present",
    location: "Grameenphone (GP) SOC, Bashundhara, Dhaka",
    points: [
      "Monitor and support Huawei 5G Core platforms — UDM, AAA, ENUM, and iMaster MAE — ensuring service availability and operational stability",
      "Track system alarms, infrastructure health, and performance KPIs; perform initial troubleshooting and coordinate resolution with L2/L3 engineering teams",
      "Prepare daily operational reports, KPI summaries, incident updates, and shift handover documentation for Huawei and Grameenphone operations",
      "Collaborate with Huawei, ZTE, and customer engineering teams during incident handling, maintenance activities, and service restoration",
      "Follow standard operating procedures (SOPs) to support reliable 24×7 telecom infrastructure operations",
    ],
    tags: ["Huawei 5G Core", "iMaster MAE", "NOC Operations", "Incident Management"],
  },
  {
    company: "Amber IT Ltd",
    role: "Assistant Network Engineer — Radio Frequency",
    period: "Oct 2025 — Feb 2026",
    location: "Gulshan-1, Dhaka",
    points: [
      "Assisted in RF planning, link budgeting, and optimization for PTP/PTMP connections",
      "Installed, aligned, and tested microwave and antenna radios; conducted line-of-sight and site surveys",
      "Performed spectrum analysis and troubleshot interference issues to keep RF links stable",
      "Coordinated with the NOC for incident response, outage resolution, and maintenance windows",
      "Configured and validated L2/L3 network components, including VLANs, trunks, and routing basics",
    ],
    tags: ["RF Planning", "Microwave Radio", "Spectrum Analysis", "VLANs"],
  },
  {
    company: "Isharifi Limited",
    role: "IT Executive — E-commerce & System Support",
    period: "Nov 2024 — Oct 2025",
    location: "Dhaka, Bangladesh",
    points: [
      "Provided IT and systems support in an enterprise environment",
      "Assisted in maintaining network and server reliability",
      "Ensured smooth day-to-day IT operations for the e-commerce platform",
    ],
    tags: ["IT Support", "System Administration", "E-commerce Operations"],
  },
];

export const education = [
  {
    degree: "MSc in IT System Security (In Progress)",
    school: "Bangladesh University of Professionals (BUP)",
    period: "Jan 2025 — Present",
    location: "Dhaka, Bangladesh",
    details: "Graduate coursework in IT systems security, building on hands-on infrastructure and network operations experience.",
  },
  {
    degree: "B.Sc. in Computer Science & Engineering",
    school: "City University, Dhaka",
    period: "Completed 2024",
    location: "Dhaka, Bangladesh",
    details: "Undergraduate foundation in computer science, networks, and systems.",
  },
];

export const skillCategories = [
  {
    category: "Cloud & Virtualization",
    icon: "Cloud",
    skills: ["AWS (EC2, VPC, IAM, S3)", "Huawei FusionCloud", "VMware ESXi", "VirtualBox", "Docker", "Cloud Monitoring"],
  },
  {
    category: "Linux & Infrastructure",
    icon: "Terminal",
    skills: ["RHCSA", "Ubuntu Administration", "Shell (Bash)", "SSH", "User & Permission Management", "System Hardening"],
  },
  {
    category: "Telecom & Enterprise Infrastructure",
    icon: "Radio",
    skills: ["Huawei 5G Core (UDM, AAA, ENUM)", "iMaster MAE", "CyberArk PAM", "Firewall Policies", "VPN Management"],
  },
  {
    category: "Networking",
    icon: "Network",
    skills: ["TCP/IP", "DNS & DHCP", "VLANs", "Routing", "Network Segmentation", "Troubleshooting"],
  },
  {
    category: "Automation & Version Control",
    icon: "Code2",
    skills: ["Bash", "Python", "Git"],
  },
  {
    category: "Operations & Documentation",
    icon: "ClipboardList",
    skills: ["Performance Monitoring", "Incident Management", "System Logging", "Dashboard Monitoring", "SOP Compliance"],
  },
];

export const certifications = [
  { name: "Red Hat Certified System Administrator (RHCSA)", issuer: "Linux Pathshala", date: "2025", credentialUrl: "" },
  { name: "AWS Certified Cloud Practitioner", issuer: "Amazon Web Services", date: "2024", credentialUrl: "" },
  { name: "HCIA – Cloud Computing", issuer: "Huawei-BUET ICT Academy", date: "2023 – 2024", credentialUrl: "" },
];

export const achievement = {
  title: "Huawei ICT Competition — Cloud Track",
  result: "7th Place, Bangladesh Round",
};

export const cloudLabs = [
  {
    title: "AWS Cloud Practitioner — Hands-On Labs",
    description: "Practiced core AWS services — EC2, VPC, IAM, and S3 — through guided labs while preparing for the AWS Certified Cloud Practitioner exam.",
    tags: ["AWS", "EC2", "VPC", "IAM"],
  },
  {
    title: "HCIA Cloud Computing Labs",
    description: "Completed hands-on virtualization and cloud fundamentals labs through the Huawei-BUET ICT Academy program, covering Huawei FusionCloud.",
    tags: ["Huawei FusionCloud", "Virtualization"],
  },
  {
    title: "RHCSA Linux Administration Labs",
    description: "Completed Red Hat Certified System Administrator coursework covering user and permission management, shell scripting, and system hardening on RHEL.",
    tags: ["Linux", "RHCSA", "Bash", "System Hardening"],
  },
  {
    title: "Virtualization Practice — ESXi & VirtualBox",
    description: "Built and managed virtual machine environments using VMware ESXi and VirtualBox to practice provisioning and core infrastructure concepts.",
    tags: ["VMware ESXi", "VirtualBox", "Docker"],
  },
  {
    title: "CyberArk PAM Fundamentals",
    description: "Explored privileged access management concepts and workflows using CyberArk PAM in an enterprise support context.",
    tags: ["CyberArk", "PAM", "Access Security"],
  },
];

// Real, verifiable work only — add more here as you ship things you can talk
// through in an interview. github/live can be left blank if there's no link yet.
export const projects = [
  {
    title: "Edge Computing in the Cloud",
    description:
      "Undergraduate thesis exploring how edge computing architectures reduce latency for latency-sensitive applications built on AWS.",
    tags: ["AWS", "Edge Computing", "Cloud Architecture"],
    github: "",
    live: "",
    status: "Thesis",
  },
  {
    title: "RF Signal Classification & Modulation Recognition",
    description:
      "Ongoing thesis applying a CNN–LSTM hybrid deep learning model to classify RF signals and recognize modulation schemes for defense and security applications.",
    tags: ["Deep Learning", "CNN-LSTM", "RF Signal Processing", "Python"],
    github: "",
    live: "",
    status: "In Progress",
  },
];

export const timeline = [
  { year: "2023 – 24", title: "HCIA – Cloud Computing", description: "Completed Huawei's cloud computing certification via the Huawei-BUET ICT Academy." },
  { year: "2024", title: "B.Sc. Completed", description: "Graduated in Computer Science & Engineering from City University, Dhaka." },
  { year: "2024", title: "AWS Certified Cloud Practitioner", description: "Earned AWS's foundational cloud certification." },
  { year: "Nov 2024", title: "Started Career", description: "Joined Isharifi Limited as an IT Executive supporting e-commerce systems." },
  { year: "Jan 2025", title: "Began MSc in IT System Security", description: "Started graduate studies at Bangladesh University of Professionals (BUP)." },
  { year: "2025", title: "RHCSA Certified", description: "Earned the Red Hat Certified System Administrator credential via Linux Pathshala." },
  { year: "Oct 2025", title: "Joined Amber IT", description: "Started as Assistant Network Engineer, Radio Frequency." },
  { year: "Feb 2026", title: "Joined Huawei Technologies Bangladesh", description: "Started as a Network Operations Center Engineer (L1), supporting 5G Core platforms." },
];
