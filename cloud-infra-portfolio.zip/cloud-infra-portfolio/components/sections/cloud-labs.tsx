"use client";

import { motion } from "framer-motion";
import { FlaskConical } from "lucide-react";
import { cloudLabs } from "@/lib/data";
import { SectionHeading, Card, Badge } from "@/components/ui";
import { staggerContainer, staggerItem, viewportOnce } from "@/lib/motion";

export function CloudLabs() {
  return (
    <section id="cloud-labs" className="section-y border-y border-border bg-muted/40">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Cloud Labs"
          title="Hands-on cloud & network labs"
          description="Hands-on practice behind my certifications — building real skills before they're needed in production."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {cloudLabs.map((lab) => (
            <motion.div key={lab.title} variants={staggerItem}>
              <Card className="h-full">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                  <FlaskConical size={16} />
                </span>
                <h3 className="mt-4 font-semibold text-foreground">{lab.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{lab.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {lab.tags.map((t) => (
                    <Badge key={t}>{t}</Badge>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
