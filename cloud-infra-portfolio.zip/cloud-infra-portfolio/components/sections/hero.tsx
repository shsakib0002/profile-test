"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Download, ChevronDown } from "lucide-react";
import { siteConfig, heroBadges } from "@/lib/data";
import { Button, Badge, StatusDot } from "@/components/ui";
import { staggerContainer, staggerItem } from "@/lib/motion";

const nodes = [
  { id: "a", x: 40, y: 255, r: 5 },
  { id: "b", x: 145, y: 70, r: 5 },
  { id: "c", x: 225, y: 195, r: 6 },
  { id: "d", x: 325, y: 55, r: 5 },
  { id: "e", x: 365, y: 215, r: 5 },
  { id: "f", x: 205, y: 300, r: 5 },
  { id: "hub", x: 105, y: 175, r: 9 },
];

const edges: [string, string][] = [
  ["a", "hub"],
  ["hub", "b"],
  ["hub", "c"],
  ["c", "f"],
  ["c", "e"],
  ["b", "d"],
  ["d", "e"],
  ["c", "d"],
];

function findNode(id: string) {
  return nodes.find((n) => n.id === id)!;
}

function NetworkGraphic() {
  const reduceMotion = useReducedMotion();

  return (
    <svg
      viewBox="0 0 400 340"
      className="h-full w-full"
      role="img"
      aria-label="Illustration of a connected network topology"
    >
      {edges.map(([from, to], i) => {
        const a = findNode(from);
        const b = findNode(to);
        return (
          <line
            key={i}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke="rgb(var(--border))"
            strokeWidth={1.5}
          />
        );
      })}

      {!reduceMotion && (
        <>
          <motion.circle
            r={3.5}
            fill="rgb(var(--accent))"
            animate={{
              cx: [findNode("a").x, findNode("hub").x, findNode("c").x, findNode("e").x],
              cy: [findNode("a").y, findNode("hub").y, findNode("c").y, findNode("e").y],
              opacity: [0, 1, 1, 0],
            }}
            transition={{ duration: 5, repeat: Infinity, ease: "linear", times: [0, 0.33, 0.66, 1] }}
          />
          <motion.circle
            r={3.5}
            fill="rgb(var(--primary))"
            animate={{
              cx: [findNode("d").x, findNode("c").x, findNode("hub").x, findNode("b").x],
              cy: [findNode("d").y, findNode("c").y, findNode("hub").y, findNode("b").y],
              opacity: [0, 1, 1, 0],
            }}
            transition={{ duration: 4.5, repeat: Infinity, ease: "linear", delay: 1.6, times: [0, 0.33, 0.66, 1] }}
          />
        </>
      )}

      {nodes.map((n) => (
        <g key={n.id}>
          {n.id === "hub" && (
            <circle cx={n.x} cy={n.y} r={n.r + 8} fill="rgb(var(--accent))" opacity={0.12} className={reduceMotion ? "" : "animate-ping-slow"} />
          )}
          <circle
            cx={n.x}
            cy={n.y}
            r={n.r}
            fill={n.id === "hub" ? "rgb(var(--accent))" : "rgb(var(--background))"}
            stroke={n.id === "hub" ? "rgb(var(--accent))" : "rgb(var(--muted-foreground))"}
            strokeWidth={1.5}
          />
        </g>
      ))}
    </svg>
  );
}

export function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-[92vh] items-center overflow-hidden border-b border-border pt-16"
    >
      <div
        className="absolute inset-0 bg-grid-faint bg-grid opacity-[0.5] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_0%,black_10%,transparent_75%)]"
        aria-hidden="true"
      />

      <div className="container-px relative mx-auto grid max-w-content items-center gap-16 py-20 lg:grid-cols-[1.1fr_0.9fr] lg:gap-8">
        <motion.div variants={staggerContainer} initial="hidden" animate="visible">
          <motion.div variants={staggerItem} className="mb-6">
            <StatusDot label={siteConfig.availability} />
          </motion.div>

          <motion.p
            variants={staggerItem}
            className="mb-4 font-mono text-sm font-medium uppercase tracking-[0.2em] text-accent"
          >
            {siteConfig.role}
          </motion.p>

          <motion.h1
            variants={staggerItem}
            className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl"
          >
            {siteConfig.name}
          </motion.h1>

          <motion.p
            variants={staggerItem}
            className="mt-6 max-w-xl text-balance text-lg leading-relaxed text-muted-foreground"
          >
            {siteConfig.tagline} Currently at <span className="text-foreground">{siteConfig.company}</span>,
            working across AWS, Linux, and enterprise networking.
          </motion.p>

          <motion.div variants={staggerItem} className="mt-9 flex flex-wrap items-center gap-3">
            <Button href={siteConfig.resumeUrl} download variant="primary">
              <Download size={16} />
              Download Résumé
            </Button>
            <Button href="#contact" variant="outline">
              Get in touch
              <ArrowRight size={16} />
            </Button>
          </motion.div>

          <motion.div variants={staggerItem} className="mt-10 flex flex-wrap gap-2">
            {heroBadges.map((b) => (
              <Badge key={b}>{b}</Badge>
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
          className="relative hidden aspect-square w-full max-w-md justify-self-center lg:block"
        >
          <NetworkGraphic />
        </motion.div>
      </div>

      <motion.a
        href="#about"
        aria-label="Scroll to About section"
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 text-muted-foreground transition-colors hover:text-accent sm:block"
      >
        <ChevronDown size={22} />
      </motion.a>
    </section>
  );
}
