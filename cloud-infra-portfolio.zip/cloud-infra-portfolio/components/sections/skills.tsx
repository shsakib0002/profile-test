"use client";

import { motion } from "framer-motion";
import { Cloud, Terminal, Radio, Network, Code2, ClipboardList, type LucideIcon } from "lucide-react";
import { skillCategories } from "@/lib/data";
import { SectionHeading, Card, Badge } from "@/components/ui";
import { staggerContainer, staggerItem, viewportOnce } from "@/lib/motion";

const iconMap: Record<string, LucideIcon> = {
  Cloud,
  Terminal,
  Radio,
  Network,
  Code2,
  ClipboardList,
};

export function Skills() {
  return (
    <section id="skills" className="section-y">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Skills"
          title="Technical skills"
          description="Tools and technologies I use to design, deploy, and operate infrastructure."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {skillCategories.map((cat) => {
            const Icon = iconMap[cat.icon] ?? Code2;
            return (
              <motion.div key={cat.category} variants={staggerItem}>
                <Card className="h-full">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                      <Icon size={17} />
                    </span>
                    <h3 className="font-semibold text-foreground">{cat.category}</h3>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {cat.skills.map((s) => (
                      <Badge key={s}>{s}</Badge>
                    ))}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
