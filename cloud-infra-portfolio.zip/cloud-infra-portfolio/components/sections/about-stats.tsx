"use client";

import { motion } from "framer-motion";
import { MapPin, Briefcase, GraduationCap, Activity } from "lucide-react";
import { about, siteConfig, stats } from "@/lib/data";
import { SectionHeading, Card, AnimatedCounter } from "@/components/ui";
import { staggerContainer, staggerItem, fadeUp, viewportOnce } from "@/lib/motion";

export function About() {
  return (
    <section id="about" className="section-y">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="About"
          title="Engineering the infrastructure behind reliable services"
          description="A quick look at what I do day to day and the systems I keep running."
        />

        <div className="grid gap-12 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={viewportOnce}
              className="space-y-5"
            >
              {about.paragraphs.map((p, i) => (
                <motion.p key={i} variants={staggerItem} className="text-base leading-relaxed text-muted-foreground">
                  {p}
                </motion.p>
              ))}
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={viewportOnce}
              className="mt-10 grid gap-4 sm:grid-cols-2"
            >
              {about.highlights.map((h) => (
                <motion.div key={h.title} variants={staggerItem} className="rounded-lg border border-border p-4">
                  <p className="text-sm font-semibold text-foreground">{h.title}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{h.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>

          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={viewportOnce}>
            <Card className="hover:translate-y-0 sticky top-24">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Currently</p>
              <div className="mt-4 space-y-4">
                <div className="flex items-start gap-3">
                  <Briefcase size={17} className="mt-0.5 shrink-0 text-accent" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{siteConfig.role}</p>
                    <p className="text-sm text-muted-foreground">{siteConfig.company}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin size={17} className="mt-0.5 shrink-0 text-accent" />
                  <p className="text-sm text-muted-foreground">{siteConfig.location}</p>
                </div>
                <div className="flex items-start gap-3">
                  <GraduationCap size={17} className="mt-0.5 shrink-0 text-accent" />
                  <p className="text-sm text-muted-foreground">Pursuing MSc in IT System Security, BUP</p>
                </div>
                <div className="flex items-start gap-3">
                  <Activity size={17} className="mt-0.5 shrink-0 text-accent" />
                  <p className="text-sm text-muted-foreground">RHCSA, AWS & HCIA Cloud certified</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function Stats() {
  return (
    <section id="stats" className="border-y border-border bg-muted/40">
      <div className="container-px mx-auto max-w-content py-14">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="grid grid-cols-2 gap-6 lg:grid-cols-4"
        >
          {stats.map((s) => (
            <motion.div key={s.label} variants={staggerItem} className="text-center lg:text-left">
              <p className="font-mono text-3xl font-semibold text-foreground sm:text-4xl">
                <AnimatedCounter value={s.value} suffix={s.suffix} decimals={s.value % 1 !== 0 ? 1 : 0} />
              </p>
              <p className="mt-1.5 text-sm text-muted-foreground">{s.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
