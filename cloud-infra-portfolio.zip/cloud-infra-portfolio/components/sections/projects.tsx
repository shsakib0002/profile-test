"use client";

import { motion } from "framer-motion";
import { Code2, ArrowUpRight } from "lucide-react";
import { projects } from "@/lib/data";
import { SectionHeading, Card, Badge } from "@/components/ui";
import { staggerContainer, staggerItem, viewportOnce } from "@/lib/motion";

export function Projects() {
  return (
    <section id="projects" className="section-y">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Projects"
          title="Featured projects"
          description="Research and thesis work applying cloud and RF concepts to real problems."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="grid gap-5 sm:grid-cols-2"
        >
          {projects.map((p) => (
            <motion.div key={p.title} variants={staggerItem}>
              <Card className="h-full">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-foreground">{p.title}</h3>
                    {p.status && (
                      <span className="mt-1.5 inline-flex items-center rounded-md bg-muted px-2 py-0.5 font-mono text-[11px] text-accent">
                        {p.status}
                      </span>
                    )}
                  </div>
                  <div className="flex shrink-0 gap-3">
                    {p.github && (
                      <a
                        href={p.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`${p.title} source on GitHub`}
                        className="text-muted-foreground transition-colors hover:text-accent"
                      >
                        <Code2 size={17} />
                      </a>
                    )}
                    {p.live && (
                      <a
                        href={p.live}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`${p.title} live link`}
                        className="text-muted-foreground transition-colors hover:text-accent"
                      >
                        <ArrowUpRight size={17} />
                      </a>
                    )}
                  </div>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <Badge key={t}>{t}</Badge>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
