"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Download, Mail, MapPin, Link2, Code2, Send, CheckCircle2 } from "lucide-react";
import { siteConfig } from "@/lib/data";
import { Button, Card, SectionHeading, StatusDot } from "@/components/ui";
import { fadeUp, staggerContainer, staggerItem, viewportOnce } from "@/lib/motion";

export function ResumeCta() {
  return (
    <section id="resume" className="section-y">
      <div className="container-px mx-auto max-w-content">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-card to-accent/10 px-8 py-14 text-center sm:px-16"
        >
          <div
            className="absolute inset-0 bg-grid-faint bg-grid opacity-30 [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,black,transparent)]"
            aria-hidden="true"
          />
          <div className="relative">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent">Resume</p>
            <h2 className="mx-auto mt-3 max-w-lg text-balance text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
              Want the full picture of my experience?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
              Download a complete PDF summary of my roles, certifications, and technical skills.
            </p>
            <div className="mt-7">
              <Button href={siteConfig.resumeUrl} download variant="primary">
                <Download size={16} />
                Download Résumé (PDF)
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function ContactForm() {
  const [status, setStatus] = React.useState<"idle" | "sending" | "sent">("idle");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("sending");
    // This form is UI-only. Connect it to a service such as Formspree, Resend,
    // or your own API route before relying on it to deliver real messages.
    setTimeout(() => setStatus("sent"), 900);
  }

  const inputClasses =
    "mt-1.5 w-full rounded-lg border border-border bg-background px-3.5 py-2.5 text-sm text-foreground outline-none transition-colors focus:border-accent";

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="text-xs font-medium text-muted-foreground">
            Name
          </label>
          <input id="name" name="name" required placeholder="Your name" className={inputClasses} />
        </div>
        <div>
          <label htmlFor="email" className="text-xs font-medium text-muted-foreground">
            Email
          </label>
          <input id="email" name="email" type="email" required placeholder="you@company.com" className={inputClasses} />
        </div>
      </div>
      <div>
        <label htmlFor="message" className="text-xs font-medium text-muted-foreground">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={5}
          placeholder="Tell me a bit about the role or opportunity."
          className={`${inputClasses} resize-none`}
        />
      </div>
      <button
        type="submit"
        disabled={status !== "idle"}
        className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-white transition-all hover:bg-primary/90 disabled:opacity-70 sm:w-auto"
      >
        {status === "idle" && (
          <>
            Send message <Send size={15} />
          </>
        )}
        {status === "sending" && "Sending…"}
        {status === "sent" && (
          <>
            Message sent <CheckCircle2 size={15} />
          </>
        )}
      </button>
    </form>
  );
}

export function Contact() {
  return (
    <section id="contact" className="section-y border-t border-border">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Contact"
          title="Let's talk infrastructure"
          description="Open to full-time roles, contract work, and conversations about cloud & networking."
        />

        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={viewportOnce}
            className="space-y-3"
          >
            <motion.div variants={staggerItem} className="mb-2">
              <StatusDot label={siteConfig.availability} />
            </motion.div>
            <motion.a
              variants={staggerItem}
              href={`mailto:${siteConfig.email}`}
              className="flex items-center gap-3 rounded-lg border border-border p-4 text-sm text-foreground transition-colors hover:border-accent hover:text-accent"
            >
              <Mail size={17} className="shrink-0 text-accent" />
              {siteConfig.email}
            </motion.a>
            <motion.div
              variants={staggerItem}
              className="flex items-center gap-3 rounded-lg border border-border p-4 text-sm text-foreground"
            >
              <MapPin size={17} className="shrink-0 text-accent" />
              {siteConfig.location}
            </motion.div>
            <motion.a
              variants={staggerItem}
              href={siteConfig.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 rounded-lg border border-border p-4 text-sm text-foreground transition-colors hover:border-accent hover:text-accent"
            >
              <Link2 size={17} className="shrink-0 text-accent" />
              Connect on LinkedIn
            </motion.a>
            <motion.a
              variants={staggerItem}
              href={siteConfig.github}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 rounded-lg border border-border p-4 text-sm text-foreground transition-colors hover:border-accent hover:text-accent"
            >
              <Code2 size={17} className="shrink-0 text-accent" />
              View GitHub profile
            </motion.a>
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={viewportOnce}>
            <Card className="hover:translate-y-0 hover:shadow-none">
              <ContactForm />
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
