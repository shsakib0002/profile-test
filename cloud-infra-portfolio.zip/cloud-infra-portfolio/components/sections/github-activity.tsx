import { Code2 } from "lucide-react";
import { siteConfig } from "@/lib/data";
import { SectionHeading, Card } from "@/components/ui";

async function getGithubStats() {
  try {
    const res = await fetch(`https://api.github.com/users/${siteConfig.githubUsername}`, {
      next: { revalidate: 3600 },
      headers: { Accept: "application/vnd.github+json" },
    });
    if (!res.ok) throw new Error("GitHub API request failed");
    const data = await res.json();
    return {
      repos: data.public_repos ?? 0,
      followers: data.followers ?? 0,
    };
  } catch {
    return { repos: 0, followers: 0 };
  }
}

export async function GithubActivity() {
  const stats = await getGithubStats();

  return (
    <section id="github-activity" className="section-y border-t border-border">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="GitHub Activity"
          title="Open-source & lab activity"
          description="A live look at my public contribution history."
        />

        <Card className="hover:translate-y-0 hover:shadow-none">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <a
              href={siteConfig.github}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 font-mono text-sm text-foreground transition-colors hover:text-accent"
            >
              <Code2 size={18} className="text-accent" />@{siteConfig.githubUsername}
            </a>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <span>
                <span className="font-medium text-foreground">{stats.repos}</span> repositories
              </span>
              <span>
                <span className="font-medium text-foreground">{stats.followers}</span> followers
              </span>
            </div>
          </div>

          <div className="mt-6 overflow-x-auto rounded-lg border border-border bg-background p-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`https://ghchart.rshah.org/2563EB/${siteConfig.githubUsername}`}
              alt={`${siteConfig.githubUsername}'s GitHub contribution graph`}
              className="min-w-[640px]"
              loading="lazy"
              width={720}
              height={112}
            />
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            Replace <code className="font-mono text-accent">githubUsername</code> in lib/data.ts to show your own activity.
          </p>
        </Card>
      </div>
    </section>
  );
}
