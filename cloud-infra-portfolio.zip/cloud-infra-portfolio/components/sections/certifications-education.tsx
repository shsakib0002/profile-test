"use client";

import { motion } from "framer-motion";
import { Award, ExternalLink, GraduationCap, Trophy } from "lucide-react";
import { certifications, education, achievement } from "@/lib/data";
import { SectionHeading, Card } from "@/components/ui";
import { staggerContainer, staggerItem, fadeUp, viewportOnce } from "@/lib/motion";

export function Certifications() {
  return (
    <section id="certifications" className="section-y border-t border-border">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Certifications"
          title="Certifications"
          description="Vendor and industry credentials that back up the skills above."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {certifications.map((cert) => (
            <motion.div key={cert.name} variants={staggerItem}>
              <Card className="flex h-full flex-col">
                <div className="flex items-start justify-between gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                    <Award size={18} />
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">{cert.date}</span>
                </div>
                <h3 className="mt-4 text-sm font-semibold leading-snug text-foreground">{cert.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{cert.issuer}</p>
                {cert.credentialUrl && (
                  <a
                    href={cert.credentialUrl}
                    className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-accent hover:underline"
                  >
                    Verify credential <ExternalLink size={12} />
                  </a>
                )}
              </Card>
            </motion.div>
          ))}

          {/* Competition placement — same grid, distinct icon and treatment */}
          <motion.div variants={staggerItem}>
            <Card className="flex h-full flex-col border-accent/30">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                <Trophy size={18} />
              </span>
              <h3 className="mt-4 text-sm font-semibold leading-snug text-foreground">{achievement.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{achievement.result}</p>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

export function Education() {
  return (
    <section id="education" className="section-y border-t border-border">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading eyebrow="Education" title="Education" />

        <div className="space-y-6">
          {education.map((ed) => (
            <motion.div key={ed.degree} variants={fadeUp} initial="hidden" whileInView="visible" viewport={viewportOnce}>
              <Card>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                      <GraduationCap size={18} />
                    </span>
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">{ed.degree}</h3>
                      <p className="text-sm text-accent">{ed.school}</p>
                    </div>
                  </div>
                  <div className="text-left sm:text-right">
                    <p className="font-mono text-sm text-muted-foreground">{ed.period}</p>
                    <p className="text-xs text-muted-foreground">{ed.location}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{ed.details}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
