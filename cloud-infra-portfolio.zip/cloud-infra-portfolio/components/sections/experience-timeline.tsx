"use client";

import { motion } from "framer-motion";
import { experience, timeline } from "@/lib/data";
import { SectionHeading, Card, Badge } from "@/components/ui";
import { fadeUp, viewportOnce } from "@/lib/motion";

export function Experience() {
  return (
    <section id="experience" className="section-y">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Experience"
          title="Professional experience"
          description="Roles where I've designed, operated, and scaled infrastructure in production."
        />

        <div className="space-y-6">
          {experience.map((job) => (
            <motion.div
              key={`${job.company}-${job.period}`}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewportOnce}
            >
              <Card>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{job.role}</h3>
                    <p className="text-sm text-accent">{job.company}</p>
                  </div>
                  <div className="text-left sm:text-right">
                    <p className="font-mono text-sm text-muted-foreground">{job.period}</p>
                    <p className="text-xs text-muted-foreground">{job.location}</p>
                  </div>
                </div>

                <ul className="mt-5 space-y-2.5">
                  {job.points.map((pt, i) => (
                    <li key={i} className="flex gap-2.5 text-sm leading-relaxed text-muted-foreground">
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                      {pt}
                    </li>
                  ))}
                </ul>

                <div className="mt-5 flex flex-wrap gap-2">
                  {job.tags.map((t) => (
                    <Badge key={t}>{t}</Badge>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Timeline() {
  return (
    <section id="timeline" className="section-y border-y border-border bg-muted/40">
      <div className="container-px mx-auto max-w-content">
        <SectionHeading
          eyebrow="Timeline"
          title="Career milestones"
          description="A chronological view of roles, certifications, and education."
          align="center"
        />

        <div className="relative mx-auto max-w-xl">
          <div className="absolute bottom-1 left-[5px] top-1 w-px bg-border" aria-hidden="true" />
          <div className="space-y-9">
            {timeline.map((item, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={viewportOnce}
                className="relative pl-8"
              >
                <span className="absolute left-0 top-1.5 h-2.5 w-2.5 rounded-full border-2 border-accent bg-background" />
                <span className="font-mono text-xs text-accent">{item.year}</span>
                <p className="mt-0.5 text-sm font-semibold text-foreground">{item.title}</p>
                <p className="mt-0.5 text-sm text-muted-foreground">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
