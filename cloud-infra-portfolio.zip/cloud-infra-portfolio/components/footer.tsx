import { Code2, Link2, Mail } from "lucide-react";
import { navLinks, siteConfig } from "@/lib/data";
import { StatusDot } from "@/components/ui";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border">
      <div className="container-px mx-auto grid max-w-content gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <a href="#home" className="flex items-center gap-2.5 font-semibold tracking-tight">
            <span className="flex h-8 w-8 items-center justify-center rounded-md border border-accent/40 bg-accent/10 font-mono text-xs text-accent">
              {siteConfig.initials}
            </span>
            <span className="text-sm">{siteConfig.name}</span>
          </a>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            {siteConfig.description}
          </p>
          <div className="mt-5">
            <StatusDot label={siteConfig.availability} />
          </div>
        </div>

        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Navigate</p>
          <ul className="mt-4 space-y-2.5">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-sm text-muted-foreground transition-colors hover:text-accent">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Connect</p>
          <ul className="mt-4 space-y-2.5">
            <li>
              <a
                href={`mailto:${siteConfig.email}`}
                className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-accent"
              >
                <Mail size={14} /> Email
              </a>
            </li>
            <li>
              <a
                href={siteConfig.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-accent"
              >
                <Link2 size={14} /> LinkedIn
              </a>
            </li>
            <li>
              <a
                href={siteConfig.github}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-accent"
              >
                <Code2 size={14} /> GitHub
              </a>
            </li>
          </ul>
        </div>

        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Based in</p>
          <p className="mt-4 text-sm text-muted-foreground">{siteConfig.location}</p>
          <p className="mt-2 text-sm text-muted-foreground">{siteConfig.role}</p>
          <p className="text-sm text-muted-foreground">{siteConfig.company}</p>
        </div>
      </div>

      <div className="border-t border-border py-6">
        <div className="container-px mx-auto flex max-w-content flex-col items-center justify-between gap-3 text-xs text-muted-foreground sm:flex-row">
          <p>
            © {year} {siteConfig.name}. All rights reserved.
          </p>
          <p className="font-mono">Built with Next.js, Tailwind CSS & Framer Motion.</p>
        </div>
      </div>
    </footer>
  );
}
