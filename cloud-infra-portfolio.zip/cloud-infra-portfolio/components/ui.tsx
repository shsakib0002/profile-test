"use client";

import * as React from "react";
import { motion, animate, useInView } from "framer-motion";
import { cn } from "@/lib/utils";
import { fadeUp, viewportOnce } from "@/lib/motion";

// ── Button ──────────────────────────────────────────────────────────────

type ButtonProps = React.ComponentPropsWithoutRef<"a"> & {
  variant?: "primary" | "outline" | "ghost";
  as?: "a" | "button";
};

const buttonBase =
  "inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background";

const buttonVariants: Record<string, string> = {
  primary: "bg-primary text-white hover:bg-primary/90 shadow-sm shadow-primary/25",
  outline: "border border-border text-foreground hover:border-accent hover:text-accent",
  ghost: "text-muted-foreground hover:text-accent",
};

export function Button({ variant = "primary", className, children, ...props }: ButtonProps) {
  return (
    <a className={cn(buttonBase, buttonVariants[variant], className)} {...props}>
      {children}
    </a>
  );
}

// ── Badge / tag chip ────────────────────────────────────────────────────

export function Badge({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md border border-border bg-muted px-2.5 py-1 font-mono text-[11px] tracking-tight text-muted-foreground",
        className
      )}
    >
      {children}
    </span>
  );
}

// ── Card ────────────────────────────────────────────────────────────────

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-xl hover:shadow-navy/5 dark:hover:shadow-black/20",
        className
      )}
    >
      {children}
    </div>
  );
}

// ── Status dot — the recurring "infrastructure is healthy" signature ──────

export function StatusDot({ label, className }: { label?: string; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping-slow rounded-full bg-signal" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-signal" />
      </span>
      {label && (
        <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      )}
    </span>
  );
}

// ── Section heading ─────────────────────────────────────────────────────

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
}) {
  return (
    <motion.div
      variants={fadeUp}
      initial="hidden"
      whileInView="visible"
      viewport={viewportOnce}
      className={cn("mb-12 max-w-2xl", align === "center" && "mx-auto text-center")}
    >
      <div className={cn("mb-3 flex items-center gap-3", align === "center" && "justify-center")}>
        <span className="h-px w-8 bg-accent" aria-hidden="true" />
        <span className="font-mono text-xs font-medium uppercase tracking-[0.2em] text-accent">
          {eyebrow}
        </span>
      </div>
      <h2 className="text-balance text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-base leading-relaxed text-muted-foreground">{description}</p>
      )}
    </motion.div>
  );
}

// ── Animated counter — used by the professional-statistics dashboard ──────

export function AnimatedCounter({
  value,
  suffix = "",
  decimals = 0,
}: {
  value: number;
  suffix?: string;
  decimals?: number;
}) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [display, setDisplay] = React.useState(0);

  React.useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration: 1.5,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setDisplay(v),
    });
    return () => controls.stop();
  }, [inView, value]);

  return (
    <span ref={ref}>
      {display.toFixed(decimals)}
      {suffix}
    </span>
  );
}
