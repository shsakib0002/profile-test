import { Hero } from "@/components/sections/hero";
import { About, Stats } from "@/components/sections/about-stats";
import { Experience, Timeline } from "@/components/sections/experience-timeline";
import { Skills } from "@/components/sections/skills";
import { Certifications, Education } from "@/components/sections/certifications-education";
import { CloudLabs } from "@/components/sections/cloud-labs";
import { Projects } from "@/components/sections/projects";
import { GithubActivity } from "@/components/sections/github-activity";
import { ResumeCta, Contact } from "@/components/sections/resume-contact";

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Stats />
      <Experience />
      <Timeline />
      <Skills />
      <Certifications />
      <CloudLabs />
      <Projects />
      <Education />
      <GithubActivity />
      <ResumeCta />
      <Contact />
    </>
  );
}
